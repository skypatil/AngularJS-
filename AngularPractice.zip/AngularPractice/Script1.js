
<script>
  var app = angular.module('MyApp', []);
  app.controller('MyController', function($scope, $window) { 
    $scope.redirect = function(){    
      var url = "https://www.google.com/";
      $window.location.href = url;
    }
  });
</script>

