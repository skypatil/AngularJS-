var myApp = angular
                .module("mymodule",[])
                .controller("myController",function ($scope){
                    var fruits = {
                            Mango:"F:\\angular practice\\Images\\Mango.jpg",
                            Apple:"F:\\angular practice\\Images\\Apple.jpg"
                    };
                    $scope.fruits = fruits;
                });

